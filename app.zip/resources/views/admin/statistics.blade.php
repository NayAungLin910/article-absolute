@extends('admin.layout.dashboard')
@section('content-dashboard')
    <div id="root"></div>
    <script src="{{ mix('/js/statistics.js') }}"></script>
@endsection