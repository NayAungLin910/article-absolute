import React, { Fragment } from "react";

const Home = () => {
    return (
        <Fragment>
          <h1>Home</h1>
        </Fragment>
    );
};

export default Home;
