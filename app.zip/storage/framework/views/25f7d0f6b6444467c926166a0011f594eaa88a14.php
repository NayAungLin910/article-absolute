
<?php $__env->startSection('title-meta'); ?>
    <title>Absolute - Profile</title>
    <meta name="description" content="Absolute Profile">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .cus-con {
            background: rgb(9, 45, 44);
            background: linear-gradient(335deg, rgba(9, 45, 44, 1) 0%, rgba(92, 178, 223, 1) 80%);
            border-radius: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-5">
            <div class="cus-con p-1 table-responsive">
                <table class="table table-borderless">
                    <tr>
                        <td>
                            <img src="<?php echo e($user->image); ?>" class="rounded-circle" alt="<?php echo e($user->name); ?>" class="text-center">
                        </td>
                        <td>
                            <table class="table table-borderless text-white">
                                <tr>
                                    <td><strong><?php echo e($user->name); ?></strong></td>
                                </tr>
                                <tr>
                                    <td><strong><?php echo e($user->email); ?></strong></td>
                                </tr>
                                <tr>
                                    <td>
                                        <strong>
                                            Role:
                                            <span class="badge badge-primary">
                                                <?php echo e($user->role); ?>

                                            </span>
                                        </strong>
                                    </td>
                                </tr>
                                <?php if(auth()->user()->role === 'moderator' || auth()->user()->role === 'admin'): ?>
                                    <tr>
                                        <td>
                                            <strong>
                                                Article Count:
                                                <span class="badge badge-primary">
                                                    <?php echo e($user->article_count); ?>

                                                </span>
                                            </strong>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <tr>
                                    <td>
                                        <strong>
                                            Favourite Articles:
                                            <span class="badge badge-primary">
                                                <?php echo e($user->fav_count); ?>

                                            </span>
                                        </strong>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>

            </div>
        </div>
        <div class="col-sm-6">
            <table class="table">
                <thead>
                    <tr>
                        <th>
                            <h4>Favourtie articles</h4>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($user->fav !== ''): ?>
                        <?php $__currentLoopData = $user->fav->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(url('/article-view/' . $f->slug)); ?>">
                                        <?php if($f->header->file == 'image'): ?>
                                            <img src="<?php echo e($f->header->file_path); ?>" class="img-fluid"
                                                alt="<?php echo e($f->name); ?>" width="200" style="max-width: 100%" />
                                        <?php endif; ?>
                                        <?php if($f->header->file == 'video'): ?>
                                            <div class="ratio ratio-16x9">
                                                <video class="w-100" controls>
                                                    <source src="<?php echo e(url($f->header->file_path)); ?>" type="video/mp4">
                                                </video>
                                            </div>
                                        <?php endif; ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('/article-view/' . $f->slug)); ?>" class="text-dark">
                                        <strong>
                                            <h6><?php echo e($f->name); ?></h6>
                                        </strong>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views\profile.blade.php ENDPATH**/ ?>