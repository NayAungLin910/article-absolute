
<?php $__env->startSection('title-meta'); ?>
    <title>Absolute - Categories</title>
    <meta name="description" content="Categories absolute">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3><i class="fa-solid fa-tag"></i> Categories</h3>
    <form action="" method="POST">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <div class="form-outline">
                <input type="search" name="search" id="form1" class="form-control" />
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-search"></i>
            </button>
        </div>
    </form>
    <br />
    <div>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <h5><i class="fa-solid fa-tag"></i> <?php echo e($c->name); ?></h5>
                <div class="row">
                    <?php if(sizeof($c->article) > 0): ?>
                        <?php $__currentLoopData = $c->article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->index < 3): ?>
                                <div class="col-sm-4">
                                    <a href="<?php echo e(url('/article-view/' . $a->slug)); ?>">
                                        <div class="card" style="width: 21rem;">
                                            <?php if($a->header->file == 'image'): ?>
                                                <img src="<?php echo e($a->header->file_path); ?>" class="card-img-top"
                                                    alt="Sunset Over the Sea" />
                                            <?php endif; ?>
                                            <?php if($a->header->file == 'video'): ?>
                                                <video class="w-100" controls>
                                                    <source src="<?php echo e(url($a->header->file_path)); ?>" type="video/mp4">
                                                </video>
                                            <?php endif; ?>
                                            <div class="card-body">
                                                <p class="card-text text-dark"><strong><?php echo e($a->header->name); ?></strong></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div>
                            <span class="badge badge-secondary">No articles yet</span>
                        </div>
                    <?php endif; ?>
                    <?php if(sizeof($c->article) > 3): ?>
                        <div class="mt-3">
                            <a href="<?php echo e(url('/article-view-by-category/' . $c->slug)); ?>" class="btn btn-sm btn-primary">
                                More ...
                            </a>
                        </div>
                    <?php endif; ?>
                    <hr class="mt-2" />
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br />
    <?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views/category.blade.php ENDPATH**/ ?>