
<?php $__env->startSection('title-meta'); ?>
    <title>Absolute - <?php echo e($category->name); ?> Category</title>
    <meta name="description" content="<?php echo e($category->name); ?> absolute category">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3><i class="fa-solid fa-tag"></i> <?php echo e($category->name); ?></h3>
    <div class="row mt-3">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4">
                <a href="<?php echo e(url('/article-view/' . $a->slug)); ?>">
                    <div class="card" style="width: 21rem;">
                        <?php if($a->header->file == 'image'): ?>
                            <img src="<?php echo e($a->header->file_path); ?>" class="card-img-top" alt="Sunset Over the Sea" />
                        <?php endif; ?>
                        <?php if($a->header->file == 'video'): ?>
                            <video class="w-100" controls>
                                <source src="<?php echo e(url($a->header->file_path)); ?>" type="video/mp4">
                            </video>
                        <?php endif; ?>
                        <div class="card-body">
                            <p class="card-text text-dark"><strong><?php echo e($a->header->name); ?></strong></p>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-4">
            <?php echo e($articles->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views\article-view-by-category.blade.php ENDPATH**/ ?>