
<?php $__env->startSection('content-dashboard'); ?>
    <div id="root"></div>
    <script src="<?php echo e(mix('/js/statistics.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views/admin/statistics.blade.php ENDPATH**/ ?>