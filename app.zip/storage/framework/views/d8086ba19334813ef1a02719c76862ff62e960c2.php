
<?php $__env->startSection('title-meta'); ?>
    <title>
        Absolute - <?php echo e($article->header->name); ?></title>
    <meta name="description" content="<?php echo e($article->header->name); ?> absolute article">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        #articleDes img {
            max-width: 100%;
            width: 500px;
        }

        .cus-con {
            background: rgb(9, 45, 44);
            background: linear-gradient(335deg, rgba(9, 45, 44, 1) 0%, rgba(92, 178, 223, 1) 80%);
            border-radius: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-8">
            <h3><?php echo e($article->header->name); ?></h3>
            <br />
            <?php if($article->header->file === 'image'): ?>
                <img width="500" style="max-width: 100%" class="img-fluid" src="<?php echo e($article->header->file_path); ?>"
                    alt="<?php echo e($article->header->name); ?>" />
            <?php elseif($article->header->file === 'video'): ?>
                <div class="row">
                    <div class="col-sm-7">
                        <video class="w-100" controls>
                            <source src="<?php echo e(url($article->header->file_path)); ?>" type="video/mp4">
                        </video>
                    </div>
                </div>
            <?php endif; ?>
            <br />
            <br />
            <div id="articleDes">
                <?php echo $article->description; ?>

            </div>
            <hr />
            <div class="row">
                <div class="col-sm-8">
                    <div>
                        <p class="h5"><i class="fa-solid fa-tag" style="margin-right: 3px;"></i>Categories</p>
                        <?php $__currentLoopData = $article->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('/article-view-by-category/' . $c->slug)); ?>">
                                <span class="badge badge-primary"><?php echo e($c->name); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-sm-4">
                    <?php if(auth()->guard()->check()): ?>
                        <div id="root"></div>
                        <script>
                            window.article_slug = "<?php echo e($article->slug); ?>"
                            window.auth = <?php echo json_encode(auth()->user(), 15, 512) ?>;
                        </script>
                        <script src="<?php echo e(mix('/js/articleLike.js')); ?>"></script>
                    <?php endif; ?>
                </div>
            </div>
            <br />
            <div class="card cus-con" style="width: 18rem;">
                <div class="card-body text-white">
                    <h4 class="card-title">Author</h4>
                    <p>
                        <img src="<?php echo e($article->user->image); ?>" class="rounded-circle" height="30"
                            alt="<?php echo e($article->user->name); ?>">
                        <span style="margin-left: 3px;" class="h6"><?php echo e($article->user->name); ?></span>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <h5 class="text-center">Latest Articles</h5>
            <div class="table-responsive">
                <table class="table table-borderless">
                    <tbody>
                        <?php $__currentLoopData = $latest_article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $la): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(url('/article-view/' . $la->slug)); ?>">
                                        <?php if($la->header->file == 'image'): ?>
                                            <img src="<?php echo e($la->header->file_path); ?>" class="img-fluid"
                                                style="max-width: 100%" alt="<?php echo e($la->header->name); ?>" />
                                        <?php endif; ?>
                                        <?php if($la->header->file == 'video'): ?>
                                            <video class="w-100" controls>
                                                <source src="<?php echo e(url($la->header->file_path)); ?>" type="video/mp4">
                                            </video>
                                        <?php endif; ?>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <h6><a href="<?php echo e(url('/article-view/' . $la->slug)); ?>"
                                            class="text-dark"><?php echo e($la->name); ?></a></h6>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views\article-view.blade.php ENDPATH**/ ?>