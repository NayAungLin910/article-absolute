
<?php $__env->startSection('content-dashboard'); ?>
    <div id="root"></div>
    <script>
        window.auth = <?php echo json_encode(auth()->user(), 15, 512) ?>;
    </script>
    <script src="<?php echo e(mix('/js/articleCreate.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views\admin\article\article.blade.php ENDPATH**/ ?>