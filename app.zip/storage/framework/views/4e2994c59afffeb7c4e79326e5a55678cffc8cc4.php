
<?php $__env->startSection('title-meta'); ?>
    <title>Absolute - Home</title>
    <meta name="description" content="Home absolute">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($featured_article !== ''): ?>
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <div class="p-3">
                    <center>
                        <a href="<?php echo e(url('/article-view/' . $featured_article->slug)); ?>">
                            <?php if($featured_article->header->file == 'image'): ?>
                                <img src="<?php echo e($featured_article->header->file_path); ?>"
                                    alt="<?php echo e($featured_article->header->name); ?>" width="400" class="img-fluid"
                                    style="max-width: 100%" />
                            <?php endif; ?>
                            <?php if($featured_article->header->file == 'video'): ?>
                                <video class="w-100" controls>
                                    <source src="<?php echo e(url($featured_article->header->file_path)); ?>" type="video/mp4">
                                </video>
                            <?php endif; ?>
                        </a>
                    </center>
                    <br />
                    <a href="<?php echo e(url('/article-view/' . $featured_article->slug)); ?>">
                        <h5 class="text-center text-dark"><?php echo e($featured_article->name); ?></h5>
                    </a>
                </div>
            </div>
            <div class="col-sm-2"></div>
        </div>
    <?php endif; ?>
    <?php if($latest_news): ?>
        <h5><i class="fa-solid fa-tag"></i> Latest news</h5>
        <div class="row">
            <?php $__currentLoopData = $latest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <a href="<?php echo e(url('/article-view/' . $l->article->slug)); ?>">
                        <div class="card" style="width: 21rem;">
                            <?php if($l->file == 'image'): ?>
                                <img src="<?php echo e($l->file_path); ?>" class="card-img-top" alt="Sunset Over the Sea" />
                            <?php endif; ?>
                            <?php if($l->file == 'video'): ?>
                                <div class="ratio ratio-16x9">
                                    <video class="w-100" controls>
                                        <source src="<?php echo e(url($l->header->file_path)); ?>" type="video/mp4">
                                    </video>
                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <p class="card-text text-dark"><strong><?php echo e($l->name); ?></strong></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr class="mt-2" />
        </div>
    <?php endif; ?>
    <?php if($inter): ?>
        <h5><i class="fa-solid fa-tag"></i> International News</h5>
        <div class="row">
            <?php if(sizeof($inter->article) > 0): ?>
                <?php $__currentLoopData = $inter->article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->index < 3): ?>
                        <div class="col-sm-4">
                            <a href="<?php echo e(url('/article-view/' . $a->slug)); ?>">
                                <div class="card" style="width: 21rem;">
                                    <?php if($a->header->file == 'image'): ?>
                                        <img src="<?php echo e($a->header->file_path); ?>" class="card-img-top"
                                            alt="<?php echo e($a->header->name); ?>" />
                                    <?php endif; ?>
                                    <?php if($a->header->file == 'video'): ?>
                                        <div class="ratio ratio-16x9">
                                            <video class="w-100" controls>
                                                <source src="<?php echo e(url($a->header->file_path)); ?>" type="video/mp4">
                                            </video>
                                        </div>
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <p class="card-text text-dark"><strong><?php echo e($a->header->name); ?></strong></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div>
                    <span class="badge badge-secondary">No articles yet</span>
                </div>
            <?php endif; ?>
            <?php if(sizeof($inter->article) > 3): ?>
                <div class="mt-3">
                    <a href="<?php echo e(url('/article-view-by-category/' . $inter->slug)); ?>" class="btn btn-sm btn-primary">
                        More ...
                    </a>
                </div>
            <?php endif; ?>
            <hr class="mt-2" />
        </div>
    <?php endif; ?>
    <?php if($myan): ?>
        <h5><i class="fa-solid fa-tag"></i> Myanamr News</h5>
        <div class="row">
            <?php if(sizeof($myan->article) > 0): ?>
                <?php $__currentLoopData = $myan->article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->index < 3): ?>
                        <div class="col-sm-4">
                            <a href="<?php echo e(url('/article-view/' . $a->slug)); ?>">
                                <div class="card" style="width: 21rem;">
                                    <?php if($a->header->file == 'image'): ?>
                                        <img src="<?php echo e($a->header->file_path); ?>" class="card-img-top"
                                            alt="<?php echo e($a->header->name); ?>" />
                                    <?php endif; ?>
                                    <?php if($a->header->file == 'video'): ?>
                                        <div class="ratio ratio-16x9">
                                            <video class="w-100" controls>
                                                <source src="<?php echo e(url($a->header->file_path)); ?>" type="video/mp4">
                                            </video>
                                        </div>
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <p class="card-text text-dark"><strong><?php echo e($a->header->name); ?></strong></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div>
                    <span class="badge badge-secondary">No articles yet</span>
                </div>
            <?php endif; ?>
            <?php if(sizeof($myan->article) > 3): ?>
                <div class="mt-3">
                    <a href="<?php echo e(url('/article-view-by-category/' . $myan->slug)); ?>" class="btn btn-sm btn-primary">
                        More ...
                    </a>
                </div>
            <?php endif; ?>
            <hr class="mt-2" />
        </div>
    <?php endif; ?>
    <?php if($sports): ?>
        <h5><i class="fa-solid fa-tag"></i> Sports News</h5>
        <div class="row">
            <?php if(sizeof($sports->article) > 0): ?>
                <?php $__currentLoopData = $sports->article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->index < 3): ?>
                        <div class="col-sm-4">
                            <a href="<?php echo e(url('/article-view/' . $a->slug)); ?>">
                                <div class="card" style="width: 21rem;">
                                    <?php if($a->header->file == 'image'): ?>
                                        <img src="<?php echo e($a->header->file_path); ?>" class="card-img-top"
                                            alt="<?php echo e($a->header->name); ?>" />
                                    <?php endif; ?>
                                    <?php if($a->header->file == 'video'): ?>
                                        <div class="ratio ratio-16x9">
                                            <video class="w-100" controls>
                                                <source src="<?php echo e(url($a->header->file_path)); ?>" type="video/mp4">
                                            </video>
                                        </div>
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <p class="card-text text-dark"><strong><?php echo e($a->header->name); ?></strong></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div>
                    <span class="badge badge-secondary">No articles yet</span>
                </div>
            <?php endif; ?>
            <?php if(sizeof($sports->article) > 3): ?>
                <div class="mt-3">
                    <a href="<?php echo e(url('/article-view-by-category/' . $sports->slug)); ?>" class="btn btn-sm btn-primary">
                        More ...
                    </a>
                </div>
            <?php endif; ?>
            <hr class="mt-2" />
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views\home.blade.php ENDPATH**/ ?>