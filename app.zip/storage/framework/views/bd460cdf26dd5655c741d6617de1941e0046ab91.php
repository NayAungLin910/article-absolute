
<?php $__env->startSection('content-dashboard'); ?>
    <div class="row">
        <div class="col-sm-9">
            <div>
                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-dark"><i class="fa-solid fa-angle-left"
                        style="margin-right: 5px"></i>Categories</a>
            </div>
            <div class="card mt-3">
                <div class="card-header bg-dark">
                    <h4 class="text-white">Edit category</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('category.update', $category->slug)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-outline mb-4">
                            <input type="text" value="<?php echo e($category->name); ?>" name="name" class="form-control" />
                            <label class="form-label" for="form1Example1">Edit Category</label>
                        </div>
                        <?php if($errors->has('name')): ?>
                            <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-success">
                            <i class="fa-solid fa-pen-to-square" style="margin-right:3px;font-size:16px"></i>
                            Save
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views\admin\category\edit.blade.php ENDPATH**/ ?>