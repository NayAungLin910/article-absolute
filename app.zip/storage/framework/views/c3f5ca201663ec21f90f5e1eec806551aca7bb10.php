
<?php $__env->startSection('content-dashboard'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    <h4>
                        Role Management
                    </h4>
                </div>
                <div class="card-body table-responsive">
                    <form action="<?php echo e(url('/admin/role-manage')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="" class="text-dark">Search user by email</label>
                        <div class="input-group">
                            <div class="form-outline">
                                <input type="search" name="search" id="form1" class="form-control" />
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                    <?php if($search_user && $search_user !== ''): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <img src="<?php echo e($search_user->image); ?>" height="30" class="rounded-circle"
                                            alt="">
                                    </td>
                                    <td>
                                        <?php echo e($search_user->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($search_user->email); ?>

                                    </td>
                                    <td>
                                        <span class="badge badge-success"><?php echo e($search_user->role); ?></span>
                                    </td>
                                    <td>
                                        <?php if($search_user->role === 'moderator'): ?>
                                            <a href="<?php echo e(url("/admin/change-role/$search_user->id")); ?>" class="btn btn-sm btn-warning">Change to user</a>
                                        <?php endif; ?>
                                        <?php if($search_user->role === 'user'): ?>
                                            <a href="<?php echo e(url("/admin/change-role/$search_user->id")); ?>" class="btn btn-sm btn-primary">Change to moderator</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views/admin/role-manage.blade.php ENDPATH**/ ?>