
<?php $__env->startSection('content-dashboard'); ?>
    <div class="row">
        <div class="col-sm-9">
            <div>
                <a href="<?php echo e(route('category.create')); ?>" class="btn btn-success"><i class="fa-solid fa-plus"
                        style="margin-right: 5px"></i>Create Category</a>
            </div>
            <div class="input-group mt-3">
                <form action="<?php echo e(url('/mod-admin/category/search')); ?>" class="d-inline" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="input-group rounded">
                        <input type="search" name="search" class="form-control rounded" placeholder="Search"
                            aria-label="Search" aria-describedby="search-addon" required />
                        <button type="submit" value="Search" class="btn btn-sm btn-dark">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="card mt-3">
                <div class="card-header bg-dark">
                    <h4 class="text-white">Creategories</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>
                                    <strong>
                                        <h5>Name</h5>
                                    </strong>
                                </th>
                                <th>
                                    <strong>
                                        <h5>Aricle Count</h5>
                                    </strong>
                                </th>
                                <th>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(url('/article-view-by-category/' . $c->slug)); ?>">
                                            <span class="badge badge-primary bold">
                                                <?php echo e($c->name); ?>

                                            </span>
                                        </a>
                                    </td>
                                    <td>
                                        <h6><?php echo e($c->article_count); ?></h6>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('category.edit', $c->slug)); ?>" class="btn btn-sm btn-primary"
                                            style="margin-left: 5px; margin-right: 5px;"><i
                                                class="fa-solid fa-pen-to-square"></i></a>
                                        <form action="<?php echo e(route('category.destroy', $c->slug)); ?>" class="d-inline"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger"
                                                style="margin-left: 5px; margin-right: 5px;"><i
                                                    class="fa-solid fa-trash"></i></button>
                                        </form>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($categories->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\academics\self_studies\self_projects\absolute-news-project\resources\views\admin\category\index.blade.php ENDPATH**/ ?>